﻿using System;

namespace BookEntry
{
    class Book
    {
        public string nombre;
        public string apellido;
        public string numero;
        public string email;

        public static int Count { get; internal set; }

        public Book (string t,string a, string r, string e)
        {
            nombre = t;
            apellido = a;
            numero = r;
            email = e;
        }

        public override string ToString()
        {
            return nombre + "\n"+ apellido + "\n" + numero + "\n" + email;
        }

        public string ListViewContact()
        {
            string verNombre = (nombre.Length > 29) ? nombre.Substring(0, 26) + "..." : nombre;
            string verApellido= (apellido.Length>29) ? apellido.Substring(0, 26) + "..." : apellido;
            string verEmail = (email.Length > 31) ? email.Substring(0, 28) + "..." : email;

            return string.Format("{0,0} {1,4} {2,4} ({3,4})",
                                         verNombre, verApellido,verEmail, numero);
        }
    }
}