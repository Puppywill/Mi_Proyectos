﻿/*
 William A.Rosado Pérez
 y00599440
 Phonebook o Contact book
 Comp400
 wrosado9440@interbayamon.edu
 */


using System;
using System.Linq;
using System.Text;
using System.Collections.Generic; 
using System.IO;
using BookEntry;
using System.Security.Cryptography;
using System.Xml.Linq;
using System.Runtime.CompilerServices;

namespace ContactBook
{
    class ContactBook
    {
        private List<Book> entryList = new List<Book>();
       
        static void Main(string[] args)
        {
            ContactBook mj = new ContactBook();
            mj.MainMenu();
        }

        public void MainMenu()
        {

            Console.WriteLine("==========================================================================");
            Console.WriteLine("El Contact Book");

            Console.WriteLine();    

            Console.WriteLine("Creador:William A. Rosado Pérez");

            Console.WriteLine();

            Console.WriteLine("Numero de estudiante: y00599440");

            Console.WriteLine("");

            Console.WriteLine("Version:1.0");

            Console.WriteLine();

            Console.WriteLine("La ultima version: 11/14/2022");

            Console.WriteLine();

            Console.WriteLine("Descripcion");

            Console.WriteLine();

            Console.WriteLine("Esto es un Contact BOok que pueda guardar o añadir varias opciones disfrute");

            Console.WriteLine("==========================================================================");

            Console.WriteLine();

            Console.WriteLine("Press ENTER para continuar");
            Console.ReadLine();

            int option;
            do
            {
                



                Console.Clear();

                Console.WriteLine("Menu del Contact Book");
                Console.WriteLine("↓ ↓ ↓ ↓ ↓ ↓ ↓ ↓ ↓ ↓ ↓  ");
                Console.WriteLine();

                Console.WriteLine("[1] Load contacts from file.");
                Console.WriteLine("[2] Show contacts.");
                Console.WriteLine("[3] Add new contact.");
                Console.WriteLine("[4] Edit contact.");
                Console.WriteLine("[5] Remove contacts.");
                Console.WriteLine("[6] Merge duplicate contacts.");
                Console.WriteLine("[7] Store contacts to file.");
                Console.WriteLine("[8] Exit the application.");
                Console.WriteLine();

                option = GetInt("Select an option: ");

                switch (option)
                {
                    case 1:
                        ViewAListOfAllEntries();
                        break;
                    case 2:
                        VerTodosLosContacto();
                        break;

                    case 3:
                        AñadirContacto();
                        break;

                    case 4:
                        

                        edit();


                        break;


                    case 5:
                        Console.WriteLine("Nombre para eliminar contacto:");
                        string cname = Console.ReadLine();

                        Console.WriteLine("Esta seguro? (yes/no)");
                    
                        DeleteContact(cname);
                  
                        Console.WriteLine("Press ENTER to continue...");
                        Console.ReadLine();
                        break;

                    case 6:
                        LoadFromAFile();
                        Console.WriteLine("Si le da[6]  la segunda vez se duplican Precione enter continuar....");
                        Console.ReadLine();
                     
                        
                        break;

                    case 7:

                        guardar();



                        break;

                    case 8:

                        Exit();

                        break;

                    default:
                        break;
                }
            }
            while (option != 8);
        }

      //Añade el contacto

        private void AñadirContacto()
        {



            string nombre;
            string apellido;
            string gmail;
            string cell;



            



            



            Console.WriteLine("POnga su nombre");
            nombre = Console.ReadLine();
           
       
            Console.WriteLine("Ponga su apellido");
            apellido = Console.ReadLine();
            
            Console.WriteLine("Ponga su email");    
            gmail = Console.ReadLine();

            Console.WriteLine("Ponga su numero de celular");
            cell = Console.ReadLine();
         



            Book n = new Book(nombre, apellido, gmail, cell);

            entryList.Add(n);   

            /* lola  Nombre
               rosa   Rosado
            hhhh@gmail.com  gmail
            494 - 898 - 3323    numerocerlll*/



        }


        /*ESto para borrrar lo contacto lo tengo por nombre*/

        private void DeleteContact(string name)
        {





            for (int i = 0; i < entryList.Count; i++)

            {
                string result = Console.ReadLine();




                Console.WriteLine("Esta seguro que vas a confirmar para borar [y] [n]");
                result = Console.ReadLine();


                if (result == "y")
                {

                    Console.WriteLine("El Borrar fue sucesss!!!!");
                    result = Console.ReadLine();
                }
                else
                {
                    Console.WriteLine("Fue cancelado");
                }



                if (name == entryList[i].nombre)
                {
                    entryList.Remove(entryList[i]);
                }

              
            
              
                
            }
          
            

            
        }


       
        private void edit()
        {
            ContactBook c = new ContactBook();







            Console.Write("Selecione la opciones:");
            Console.WriteLine("[1]Nombre  [2]Apellido [3]gmail [4]Celular");
            string result = Console.ReadLine();

            if (result == "1")
            {
                Console.WriteLine("Entre el nombre edit:");
                string name = Console.ReadLine();

                Console.WriteLine("Esta seguro que vas a confirmar [y] [n]");
                result = Console.ReadLine();


                if (result == "y")
                {
                    name = name;
                    Console.WriteLine("El edit fue sucesss!!!!");
                }
                else
                {
                    Console.WriteLine("Fue cancelado");
                }

            }



        }





        /*         
         *        Lo que hace es buscar el contacto pone el numero que esta asignado
         */

        private void VerTodosLosContacto()
        {
            int number;
            Console.Clear();
            do
            {
                number = GetInt("Entre el numero que esta asignado: ");
            }
            while (number < 0 || number > entryList.Count);

            
           
            Console.WriteLine(entryList[number]);
            
            Console.WriteLine("Press ENTER to continue...");
            Console.ReadLine();
        }

        //Esto es para salir del app

        private void Exit()
        {
            Console.WriteLine("Exit ContactBook. Presione ENTER para salir.");
            Console.ReadLine();
        }

        private void ViewAListOfAllEntries()
        {
            Console.Clear();

            for (int i = 0; i < entryList.Count; i++)
            {
                Book e = entryList[i];
                Console.WriteLine(string.Format("[{0,3:000}] {1}", i, e.ListViewContact()));
            }

            Console.WriteLine("Press ENTER to continue...");
            Console.ReadLine();
        }





       







      private void guardar()
        {
            Console.WriteLine("YA se guardaron lo datos");
            Console.ReadLine();

            using var tell=new StreamWriter("ContactBook.txt");
            
            foreach(Book save in entryList)
            {
                tell.WriteLine(save);
            }


        }









        private void LoadFromAFile()
        {
            using (StreamReader sr = new StreamReader("ContactBook.txt"))
            {
                int entryCount = Convert.ToInt32(sr.ReadLine());

                for (int i = 0; i < entryCount; i++)
                {
                   string nombre = sr.ReadLine();
                   string apellido = sr.ReadLine();
                  
                   string email = sr.ReadLine();
                   string numero = sr.ReadLine();
                    Book entrar = new Book(nombre, apellido, email,numero);
                    entryList.Add(entrar);



                }
            }
        }

        private static int GetInt(string prompt)
        {
            while (true)
            {
                try
                {
                    Console.Write(prompt);
                    return Convert.ToInt32(Console.ReadLine());
                }
                catch
                {
                }
            }
        }
    }
}