
public class ProcessControlBlock {

	private int pid;
	private int exec_time;
	private int prioridad;
	private int block_time;
	private int total_time;
	private int state;
	private int ready_time;
	private int new_time;
	private int size;
	private int pc;
	private int contadorBloqueo;

	static int NEW = 1;
	static int READY = 2;
	static int RUNNING = 3;
	static int BLOCKED = 4;
	static int FINISHED = 5;

	public ProcessControlBlock() {

		pid = -1;
		exec_time = 0;
		prioridad = 10;
		block_time = 0;
		total_time = 0;
		ready_time = 0;
		new_time = 0;
		state = NEW;
		size = 0;
		pc = 0;
		contadorBloqueo = 0;
	}

	public ProcessControlBlock(int pid) {

		this.pid = pid;
		exec_time = 0;
		prioridad = 10;
		block_time = 0;
		total_time = 0;
		ready_time = 0;
		new_time = 0;
		state = NEW;
		size = 0;
		pc = 0;
		contadorBloqueo = 0;
	}

	public void IncrementNewTime() {
		new_time++;
	}
	
	public void setContadorBloqueo(int contador) {
		this.contadorBloqueo = contador;
	}
	
	public int getContadorBloqueo() {
		return contadorBloqueo;
	}
	
	public void bajarContadorBloqueo() {
		contadorBloqueo--;
	}
	
	public String toString() {
		return

		"PID:" + this.pid + "  Exec_Time:" + this.exec_time + " Prioridad:" + this.prioridad + " Block_Time:"
				+ this.block_time + " Total_Time:" + this.total_time + " Ready_Time:" + this.ready_time + " New_Time"
				+ this.new_time + " State:" + this.state + " Size:" + this.size + " PC:" + this.pc;
	}

	public int getNew_time() {
		return new_time;
	}

	public void setNew_time(int new_time) {
		this.new_time = new_time;
	}

	public String getStringState() {
		if (state == NEW)
			return "NEW";

		else if (state == READY)
			return "Ready";

		else if (state == RUNNING)
			return "RUNNING";

		else if (state == BLOCKED)
			return "BLOCKED";

		else if (state == FINISHED)
			return "FINISHED";

		else
			return "UNKNOWN";

	}


	
	public void IncrementReady() {

		ready_time++;
	}
	
	public void IncrementProgramCounter() 
	{
		if(pc<=size)
		pc++;
	}
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ProcessControlBlock pcb = new ProcessControlBlock();

		pcb.IncrementNewTime();

		pcb.setNew_time(pcb.getNew_time() + 1);

		System.out.println(pcb.getNew_time());

	}

	public int getPc() {
		return pc;
	}

	public void setPc(int pc) {
		this.pc = pc;
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}

	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	public int getExec_time() {
		return exec_time;
	}

	public void setExec_time(int exec_time) {
		this.exec_time = exec_time;
	}

	public int getPrioridad() {
		return prioridad;
	}

	public void setPrioridad(int prioridad) {
		this.prioridad = prioridad;
	}

	public int getBlock_time() {
		return block_time;
	}

	public void setBlock_time(int block_time) {
		this.block_time = block_time;
	}

	public int getTotal_time() {
		return total_time;
	}

	public void setTotal_time(int total_time) {
		this.total_time = total_time;
	}

	public int getState() {
		return state;
	}

	public void setState(int state) {
		this.state = state;
	}

	public int getReady_time() {
		return ready_time;
	}

	public void setReady_time(int ready_time) {
		this.ready_time = ready_time;
	}

	public boolean termino() {
		if (pc >= size)
			return true;
		return false;
	}

}
