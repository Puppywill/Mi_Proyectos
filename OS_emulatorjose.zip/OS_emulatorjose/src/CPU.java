public class CPU {

	private Proceso exec_process;
	private int timekeeper;
	private int quantumTime;

	public CPU() {
		exec_process = null;
		timekeeper = 0;
		quantumTime = 3;
		System.out.println("Se creo un cpu nuevo...");

	}

	public void timekeeper() {
		timekeeper++;
	}

	public int getQuantumTime() {
		return quantumTime;
	}

	public void setQuantumTime(int quantumTime) {
		this.quantumTime = quantumTime;
	}

	public int getProgram_counter() {
		return exec_process.getProcessControlBlock().getPc();
	}

	public Proceso getExecutingProcess() {
		return this.exec_process;
	}

	public void setexec_process(Proceso p) {
		if (isAvailable()) {
			this.exec_process = p;
			System.out.println("Se anadio el procesador: " + p + " al cpu: " + exec_process.getPid());
		}

	}

	public void deleteExecuteProcess()
	{
		exec_process = null;
	}
	

	
	
	public boolean isAvailable() {
		if (exec_process == null)
			return true;

		return false;
	}

	public void clear() {
		this.exec_process = null;
	}

	public void excute() {
		if (exec_process == null) {
			return;
		}

		int pc = exec_process.getProcessControlBlock().getPc();
		int size = exec_process.getProcessControlBlock().getSize();

		if (pc < size) {
			exec_process.incrmentPC();
		}
	}

	public boolean terminoEjecucion() {
		if (exec_process == null) {
			return true;
		}

		if (exec_process.getProcessControlBlock().termino()) {
			return true;
		}

		return false;
	}

	public String toString() {
		if (isAvailable() == false) {
			return "CPU:" + exec_process.getProcessControlBlock().getPid() + " Tiene " + this.exec_process;
		}

		return "CPU: no ningun processo........";
	}

}
