import java.util.Random;

public class Proceso   {

	private int size;
	private int pid;
	private int prioridad;
	private ProcessControlBlock pcb;
	
	
	
	
	
	public Proceso() 
	{
		pid= 1;
		size= getRandomsize(20);
		prioridad = getRandomPrioridad();
		pcb = new ProcessControlBlock();
		pcb.setSize(getRandomPrioridad());
	}
	
	
//	public String toString() 
//	{
//		String buffer= "";
//		buffer
//	}
//	
	
	public ProcessControlBlock getProcessControlBlock()
	{
		return pcb;
	}
	
	
	public Proceso(int id) 
	{
		pid=id;
		size = getRandomsize(20);
		prioridad = getRandomPrioridad();
		pcb = new ProcessControlBlock(id);
		pcb.setSize(getRandomPrioridad());
	}
	
	public Proceso(int id,int maxSize) 
	{
		pid=id;
		size = getRandomsize(maxSize);
		prioridad = getRandomPrioridad();
		pcb = new ProcessControlBlock(id);
		pcb.setSize(getRandomPrioridad());
	}
	
	
	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	public int getPrioridad() {
		return prioridad;
	}


	public void setPrioridad(int prioridad) {
		this.prioridad = prioridad;
	}

	
	
	public int getSize() 
	{
		return size;
	}


	public void setSize(int size) 
	{
		this.size = size;
	}


	public String toString() 
	{
		return "PID :" + pid +" | "+"Size:"+ size +" Prioridad: "+ prioridad;
	}
	
	public void incrmentPC() 
	{
		pcb.setPc(pcb.getPc()+1);
	}
	
	
	
  public int getRandomsize(int maxSize) 
  {
	  
	 Random rand = new Random();
	 int n = rand.nextInt(maxSize) + 1;
	 return this.size = n;
  }
	
  public int getRandomPrioridad() 
  {
	  
	 Random rand = new Random();
	 int n = rand.nextInt(15) + 1;
	 return this.prioridad = n;
  }
	
  

	
	public static void main(String[] args) {
		
		Proceso real = new Proceso();
		System.out.println(real);

	}

}
