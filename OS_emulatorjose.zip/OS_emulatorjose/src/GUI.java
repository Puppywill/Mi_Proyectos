import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.border.TitledBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.border.EtchedBorder;
import java.awt.Color;
import javax.swing.JTextField;

public class GUI {

	private JFrame frame;
	private Sistemaoperativo sto;
	private PCBGUI guipcb;
	private SettingGui settings;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GUI window = new GUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public GUI() {
		sto = new Sistemaoperativo();
		settings = new SettingGui();
		guipcb = new PCBGUI();
		initialize();

	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 904, 446);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JList pnl_finish = new JList();
		pnl_finish.setModel(sto.getFinish());
		pnl_finish.setBorder(new TitledBorder(
				new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Finish",
				TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		pnl_finish.setBounds(669, 33, 209, 136);
		frame.getContentPane().add(pnl_finish);

		JButton btnControlblocktick = new JButton("PCB_click");
		btnControlblocktick.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				guipcb.setVisible(true);
			}
		});
		btnControlblocktick.setBounds(149, 331, 159, 51);
		frame.getContentPane().add(btnControlblocktick);

		JList Disk = new JList();
		Disk.setBounds(10, 11, 215, 136);
		frame.getContentPane().add(Disk);
		Disk.setBorder(new TitledBorder(null, "Disk", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		Disk.setModel(sto.getDisco());

		JScrollPane scroll = new JScrollPane();
		scroll.setBounds(284, 94, 346, 184);
		frame.getContentPane().add(scroll);

		JList Running = new JList();
		Running.setBorder(new TitledBorder(null, "Running", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		Running.setModel(sto.getCpulist());
		scroll.setViewportView(Running);

		JList Dispatcher = new JList();
		Dispatcher.setBounds(25, 169, 209, 128);
		frame.getContentPane().add(Dispatcher);
		Dispatcher.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "New", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		Dispatcher.setModel(sto.getDispatcher());

		JScrollPane Block = new JScrollPane();
		Block.setBounds(682, 202, 196, 116);
		frame.getContentPane().add(Block);

		JList block = new JList();
		block.setBorder(new TitledBorder(null, "Block", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		Block.setViewportView(block);
		block.setModel(sto.getBlock());

		guipcb.setlista(sto.getListadePCBs());

		
//		------------------------------------------------------------------------------------------
		JButton btnNewButton = new JButton("Click_tick");
		
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

			
				
				sto.clocktick();

				Running.repaint();
				
				guipcb.settabla(sto.gettabla());

			}

		});
		
//		------------------------------------------------------------------------------------
		
		btnNewButton.setBounds(383, 331, 159, 51);
		frame.getContentPane().add(btnNewButton);

		JButton Setting = new JButton("Setting");
		Setting.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				settings.setSistemaOperativo(sto);
				settings.setVisible(true);
			}
		});
		Setting.setBounds(582, 331, 159, 51);
		frame.getContentPane().add(Setting);

	}
}
