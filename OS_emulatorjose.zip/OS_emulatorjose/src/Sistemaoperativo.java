import java.util.Random;

import javax.swing.DefaultListModel;
import javax.swing.table.DefaultTableModel;

public class Sistemaoperativo {

	private DefaultListModel<Proceso> dispatcher;
	private DefaultListModel<ProcessControlBlock> listadePCBs;
	private DefaultListModel<Proceso> disco;
	private DefaultListModel<Proceso> finish;
	private DefaultListModel<Proceso> block;
	private DefaultListModel<CPU> cpulist;
	private CPU cpu;
	private RandomGeneral ran;
	private int quantumTime;
	private int quantumTimeWatcher;
	private int cpucount;
	private DefaultTableModel pcbTable;
	private Setting setting;

	public Sistemaoperativo() {
		dispatcher = new DefaultListModel<Proceso>();
		disco = new DefaultListModel<Proceso>();
		listadePCBs = new DefaultListModel<ProcessControlBlock>();
		finish = new DefaultListModel<Proceso>();
		block = new DefaultListModel<Proceso>();
		cpulist = new DefaultListModel<CPU>();
		cpu = new CPU();
		ran = new RandomGeneral();
		setting = new Setting();

		quantumTime = 3;
		quantumTimeWatcher = 0;

		ran.setTamanoMaximo(setting.getTamanoMaximo());

		for (int x = 0; x < setting.getCpucantidad(); x++) {
			CPU cpu = new CPU();
			cpulist.addElement(cpu);

		}

		aplicarCambiosACPUs();
	}

	public Setting getSettings() {
		return setting;
	}

	public void cambiarQuantumTime() {
		this.quantumTime = setting.getQuantumTimeCantidad();
	}

	public void cambiarTamanoMaximo() {
		ran.setTamanoMaximo(setting.getTamanoMaximo());
	}

	public void aplicarCambiosACPUs() {

		int currentCPUsQty = cpulist.getSize();

		if (currentCPUsQty == setting.getCpucantidad()) {
			return;
		}

		if (currentCPUsQty < setting.getCpucantidad()) {
			for (int i = currentCPUsQty; i < this.setting.getCpucantidad(); i++) {
				CPU newCPU = new CPU();
				this.cpulist.addElement(newCPU);
			}
		} else {

			if (currentCPUsQty == 0) {
				currentCPUsQty = 1;
			}

			for (int i = this.setting.getCpucantidad(); i < currentCPUsQty; i++) {
				if (!this.cpulist.elementAt(i).isAvailable()) {
					Proceso p = cpulist.elementAt(i).getExecutingProcess();
					dispatcher.addElement(p);
					p.getProcessControlBlock().setState(2);
					this.cpulist.remove(i);
				} else {
					this.cpulist.removeElementAt(i);
				}
			}
		}
	}

	public DefaultListModel<Proceso> getBlock(){
		return block;
	}
	
	
	public DefaultTableModel gettabla() {
		String[] columnas = { "PID", "Size", "Block_Time", "Total_time", "State", "Ready_time", "New_time", "PC" };

		pcbTable = new DefaultTableModel(columnas, 0);

		for (int x = 0; x < listadePCBs.getSize(); x++) {
			Object[] pcb = { listadePCBs.elementAt(x).getPid(), listadePCBs.elementAt(x).getSize(),
					listadePCBs.elementAt(x).getBlock_time(), listadePCBs.elementAt(x).getTotal_time(),
					listadePCBs.elementAt(x).getStringState(), listadePCBs.elementAt(x).getReady_time(),
					listadePCBs.elementAt(x).getNew_time(), listadePCBs.elementAt(x).getPc() };
			pcbTable.addRow(pcb);
		}
		return pcbTable;
	}

	public void CrearProcesoNuevo() {
		Proceso p = null;
		p = ran.getRandomProceso();

		if (p != null) {
			disco.addElement(p);
			listadePCBs.addElement(p.getProcessControlBlock());
			p.getProcessControlBlock().setState(1);
//		    dispatcher.addElement(p);
		}
	}

	public DefaultListModel<CPU> getCpulist() {
		return cpulist;

	}

	private void moverdispatcher() {

		if (disco.getSize() == 0) {
			return;
		}

		if (dispatcher.getSize() <= 10) {
			Proceso c = (Proceso) disco.remove(0);
			c.getProcessControlBlock().setState(2);
			dispatcher.addElement(c);
		}
	}

	public DefaultListModel<Proceso> getDispatcher() {
		return this.dispatcher;
	}

	public DefaultListModel<Proceso> getDisco() {
		return this.disco;
	}

	public DefaultListModel<Proceso> getFinish() {
		return finish;
	}

	public DefaultListModel getListadePCBs() {
		return this.listadePCBs;
	}

	public void setquantumTime(int n) {
		quantumTime = n;
	}

	public int getquantumTime() {
		return quantumTime;
	}

	public CPU getCpu() {
		return this.cpu;
	}

	public RandomGeneral getRandomGeneral() {
		return this.ran;
	}

	public void cambiarProbabilidad() {
		if (setting.getBtnRandomMarcado()) {
			this.ran.setProabilidad(setting.getRandomProbabilidad());
		} else {
			this.ran.setProabilidad(setting.getProbabildad());
		}
	}

	public void movercpu() {
		for (int x = 0; x < cpulist.getSize(); x++) {
			if (!dispatcher.isEmpty()) {
				if (cpulist.elementAt(x).isAvailable()) {
					Proceso p = dispatcher.remove(0);
					cpulist.elementAt(x).setexec_process(p);
					p.getProcessControlBlock().setState(3);
				}
			}
		}

	}

	private void devolverarecepcion() {

		for (int x = 0; x < cpulist.getSize(); x++) {

			Proceso p = cpulist.elementAt(x).getExecutingProcess();
			if (p != null) {
				dispatcher.addElement(p);
				p.getProcessControlBlock().setState(2);
				cpulist.elementAt(x).clear();
			}
		}

	}

	private void timesharingimplementation() {
		if (this.quantumTimeWatcher < this.quantumTime) {
			this.quantumTimeWatcher++;
		} else {
			this.devolverarecepcion();
			this.movercpu();
			this.quantumTimeWatcher = 0;
		}
	}

	private void UpdateNewTime() {
		
		if(disco.isEmpty()) {
			return;
		}
		
		for (int x = 0; x < disco.getSize(); x++) {
			ProcessControlBlock p = disco.getElementAt(x).getProcessControlBlock();
			p.IncrementNewTime();
		}
	}

	private void UpdateReadyTime() {

		if (dispatcher.isEmpty())
			return;

		for (int x = 0; x < dispatcher.getSize(); x++) {
			ProcessControlBlock p = dispatcher.getElementAt(x).getProcessControlBlock();
			p.IncrementReady();
		}
	}

	private void UpdateTotalTime() {
		if(finish.isEmpty()) {
			return;
		}
		
		for(int x = 0; x < finish.getSize(); x++) {
			ProcessControlBlock p = finish.getElementAt(x).getProcessControlBlock();
			p.setTotal_time(p.getNew_time()+p.getReady_time()+p.getBlock_time());
		}
	}
	
	public void UpdateTime() {
		UpdateNewTime();
		UpdateReadyTime();
		UpdateTotalTime();
	}
	
	public boolean seBloqueo() {
		
		Random r = new Random();
		
		//Proabilidad a un 20 porciento
		int probabilidad = 20;
		
		int n = r.nextInt(100);
		
		if(n <= probabilidad) {
			return true;
		}
		
		
		return false;
	}
	
	public void bloquearProcesos() {
		for(int i = 0; i < cpulist.getSize(); i++) {
			
			if(cpulist.elementAt(i).isAvailable()) {
				continue;
			}
			
			if(seBloqueo()) {
			 
				Random r = new Random();
				
				int n = r.nextInt(setting.getTiempoBloqueado());
				
				Proceso p = cpulist.elementAt(i).getExecutingProcess();
				p.getProcessControlBlock().setContadorBloqueo(n);
				p.getProcessControlBlock().setState(4);
				block.addElement(p);
				cpulist.elementAt(i).clear();
			}
		}
	}
	
	public void manejarBloqueo() {
		if(block.isEmpty()) {
			return;
		}
		
		for(int i = 0; i < block.getSize(); i++) {
			Proceso p = block.elementAt(i);
			p.getProcessControlBlock().bajarContadorBloqueo();
			
			if(p.getProcessControlBlock().getContadorBloqueo() == 0) {
				dispatcher.addElement(p);
				p.getProcessControlBlock().setState(2);
				block.remove(i);
			}
		}
	}

	public void clocktick() {

		System.out.println("Tiempo block: " + setting.getTiempoBloqueado());
		
		
		cambiarProbabilidad();

		CrearProcesoNuevo();

		this.moverdispatcher();

		this.movercpu();

		this.bloquearProcesos();
		
		this.manejarBloqueo();
		
		timesharingimplementation();

		this.excute();

		this.terminoEjecucion();

		UpdateTime();
	}

	public void terminoEjecucion() {
		for (int x = 0; x < cpulist.getSize(); x++) {
			if (cpulist.elementAt(x).terminoEjecucion()) {
				if (cpulist.elementAt(x).getExecutingProcess() != null) {
					Proceso p = cpulist.elementAt(x).getExecutingProcess();
					finish.addElement(p);
					p.getProcessControlBlock().setState(5);
					cpulist.elementAt(x).clear();
				}
			}
		}
	}

	public void excute() {
		for (int x = 0; x < cpulist.getSize(); x++) {
			cpulist.elementAt(x).excute();

		}

	}

	public static void main(String[] args) {

	}

}
