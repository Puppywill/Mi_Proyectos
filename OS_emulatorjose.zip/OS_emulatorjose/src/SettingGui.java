import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JSlider;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.JCheckBox;

public class SettingGui extends JFrame {

	private JPanel contentPane;
	private Sistemaoperativo sto;
	private JSlider sliderCPU;
	private JLabel lblQuantum;
	private JSlider sliderQuantum;
	private JSlider sliderSize;
	private JSlider sliderProbabilidad;
	private JSlider sliderTiempoBloqueo;
	private JLabel lblPorciento;
	private JCheckBox randomCheck;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SettingGui frame = new SettingGui();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	
	public void setSistemaOperativo(Sistemaoperativo sto) {
		this.sto = sto;
	}
	
	public void cpusHandler() {
		if(sto == null) {
			return;
		}
		
		sto.getSettings().setCpucantidad((int) sliderCPU.getValue());
		sto.aplicarCambiosACPUs();
	}
	
	public void quantumTimeHandler() {
		if(sto == null) {
			return;
		}
		
		sto.getSettings().setQuantumTimeCantidad((int) sliderQuantum.getValue());
		sto.cambiarQuantumTime();
	}
	
	public void tamanoMaximoHandler() {
		if(sto == null) {
			return;
		}
		
		sto.getSettings().setTamanoMaximo((int) sliderSize.getValue());
		sto.cambiarTamanoMaximo();
	}
	
	public void botonRandomHandler() {
		if(sto == null) {
			return;
		}
		
		if(randomCheck.isSelected()) {
			sto.getSettings().setBtnMarcado(true);
			sliderProbabilidad.setEnabled(false);
		}else {
			sliderProbabilidad.setEnabled(true);
		}	
	}
	
	public void probabilidadHandler() {
		if(sto == null) {
			return;
		}
		
		sto.getSettings().setProbabilidad((int) sliderProbabilidad.getValue());
		lblPorciento.setText("%" + (int) sliderProbabilidad.getValue());
	}
	
	public void tiempoBloqueoHandler() {
		if(sto == null) {
			return;
		}
		
		
		sto.getSettings().setTiempoBloqueo((int) sliderTiempoBloqueo.getValue());
	}
	
	
	public SettingGui() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 641, 424);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblCPU = new JLabel("CPUs");
		lblCPU.setBounds(10, 11, 52, 14);
		contentPane.add(lblCPU);
		
		sliderCPU = new JSlider();
		sliderCPU.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				cpusHandler();
			}
		});
		sliderCPU.setValue(1);
		sliderCPU.setMajorTickSpacing(1);
		sliderCPU.setMinorTickSpacing(1);
		sliderCPU.setMaximum(4);
		sliderCPU.setMinimum(1);
		sliderCPU.setPaintTicks(true);
		sliderCPU.setPaintLabels(true);
		sliderCPU.setBounds(49, 11, 200, 53);
		contentPane.add(sliderCPU);
		
		JButton btnCerrar = new JButton("Cerrar");
		btnCerrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				esconder();
			}
		});
		btnCerrar.setBounds(420, 339, 89, 23);
		contentPane.add(btnCerrar);
		
		lblQuantum = new JLabel("QuantumTime");
		lblQuantum.setBounds(10, 91, 97, 14);
		contentPane.add(lblQuantum);
		
		sliderQuantum = new JSlider();
		sliderQuantum.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				quantumTimeHandler();
			}
		});
		sliderQuantum.setPaintTicks(true);
		sliderQuantum.setPaintLabels(true);
		sliderQuantum.setValue(3);
		sliderQuantum.setMinorTickSpacing(1);
		sliderQuantum.setMinimum(1);
		sliderQuantum.setMaximum(10);
		sliderQuantum.setMajorTickSpacing(1);
		sliderQuantum.setBounds(49, 132, 200, 40);
		contentPane.add(sliderQuantum);
		
		sliderSize = new JSlider();
		sliderSize.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				tamanoMaximoHandler();
			}
		});
		sliderSize.setMaximum(20);
		sliderSize.setMinorTickSpacing(1);
		sliderSize.setMinimum(1);
		sliderSize.setMajorTickSpacing(1);
		sliderSize.setPaintTicks(true);
		sliderSize.setPaintLabels(true);
		sliderSize.setBounds(338, 22, 259, 42);
		contentPane.add(sliderSize);
		
		JLabel lblSize = new JLabel("Size");
		lblSize.setBounds(296, 11, 52, 14);
		contentPane.add(lblSize);
		
		randomCheck = new JCheckBox("Random");
		randomCheck.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				botonRandomHandler();
			}
		});
		
		randomCheck.setBounds(412, 115, 97, 23);
		contentPane.add(randomCheck);
		
		sliderProbabilidad = new JSlider();
		sliderProbabilidad.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				probabilidadHandler();
			}
		});
		sliderProbabilidad.setPaintTicks(true);
		sliderProbabilidad.setPaintLabels(true);
		sliderProbabilidad.setMinorTickSpacing(10);
		sliderProbabilidad.setMinimum(10);
		sliderProbabilidad.setMajorTickSpacing(10);
		sliderProbabilidad.setBounds(338, 160, 259, 42);
		contentPane.add(sliderProbabilidad);
		
		JLabel lblProbabilidad = new JLabel("Probabilidad");
		lblProbabilidad.setBounds(283, 76, 71, 14);
		contentPane.add(lblProbabilidad);
		
		lblPorciento = new JLabel("% ");
		lblPorciento.setBounds(436, 230, 46, 14);
		contentPane.add(lblPorciento);
		
		JLabel lbTiempo = new JLabel("Tiempo Bloqueo");
		lbTiempo.setBounds(10, 230, 89, 14);
		contentPane.add(lbTiempo);
		
		sliderTiempoBloqueo = new JSlider();
		sliderTiempoBloqueo.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				tiempoBloqueoHandler();
			}
		});
		sliderTiempoBloqueo.setPaintTicks(true);
		sliderTiempoBloqueo.setPaintLabels(true);
		sliderTiempoBloqueo.setMinorTickSpacing(1);
		sliderTiempoBloqueo.setMinimum(1);
		sliderTiempoBloqueo.setMaximum(20);
		sliderTiempoBloqueo.setMajorTickSpacing(1);
		sliderTiempoBloqueo.setBounds(20, 264, 275, 40);
		contentPane.add(sliderTiempoBloqueo);
	}
	
	public void esconder() {
		this.setVisible(false);
	}
	
	public boolean isRandomSelected() {
		if(randomCheck.isSelected()) {
			return true;
		}
		
		return false;
	}
}
