import java.util.Random;

public class Setting {
	private int cpucantidad;
	private int quantumTimeCantidad;
	private int tamanoMaximo;
	private int tiempoBloqueo;
	
	private int randomProbabilidad;
	
	private int probabilidad;
	
	private boolean btnRandomMarcado;
	
	public Setting() {
		cpucantidad = 1;
		quantumTimeCantidad = 10;
		tamanoMaximo = 10;
		
		randomProbabilidad = getRandomProbabilidad();
		probabilidad = 50;
		btnRandomMarcado = false;
		tiempoBloqueo = 10;
	}

	public int getTiempoBloqueado() {
		return tiempoBloqueo;
	}
	
	public void setTiempoBloqueo(int tiempo) {
		tiempoBloqueo = tiempo;
	}
	
	public void setProbabilidad(int probabilidad) {
		this.probabilidad = probabilidad;
	}
	
	public int getProbabildad() {
		return this.probabilidad;
	}
	
	public boolean getBtnRandomMarcado() {
		if(btnRandomMarcado) {
			return true;
		}
		
		return false;
	}
	
	public void setBtnMarcado(boolean marcado) {
		this.btnRandomMarcado = marcado;
	}
	
	public int getCpucantidad() {
		return cpucantidad;
	}

	public void setCpucantidad(int cpucantidad) {
		this.cpucantidad = cpucantidad;
	}

	public int getQuantumTimeCantidad() {
		return quantumTimeCantidad;
	}

	public void setQuantumTimeCantidad(int quantumTimeCantidad) {
		this.quantumTimeCantidad = quantumTimeCantidad;
	}

	public int getTamanoMaximo() {
		return tamanoMaximo;
	}

	public void setTamanoMaximo(int tamanoMaximo) {
		this.tamanoMaximo = tamanoMaximo;
	}

	public int getRandomProbabilidad() {
		Random r = new Random();
		

		this.randomProbabilidad = r.nextInt(100) + 1;
		
		return randomProbabilidad;
	}
	
	

}
