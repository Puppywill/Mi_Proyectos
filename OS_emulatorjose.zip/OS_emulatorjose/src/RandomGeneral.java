import java.util.Random;

public class RandomGeneral {

	private int proabilidad;

	private int conteo;

	private int tamanoMaximo;

	public RandomGeneral() {
		conteo = 1;
		proabilidad = 50;
		tamanoMaximo = 20;
	}

	public Proceso getRandomProceso() {

		Random var = new Random();

		int n = var.nextInt(100) + 1;

		if (n <= proabilidad) {
			return new Proceso(conteo++,tamanoMaximo);
		} else
			return null;

	}

	public void setTamanoMaximo(int tamanoMaximo) {
		this.tamanoMaximo = tamanoMaximo;
	}
	
	public int getTamanoMaximo() {
		return tamanoMaximo;
	}
	
	public int getProabilidad() {
		return proabilidad;
	}

	public void setProabilidad(int proabilidad) {
		this.proabilidad = proabilidad;
	}
	
	public int generateRandomProbabilidad() {
		Random r = new Random();
		
		this.proabilidad = r.nextInt(100 + 1);
		
		return this.proabilidad;
	}
}
