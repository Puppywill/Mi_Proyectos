﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EShop
{
	public class EShopMain
	{
		#region Variables
		public string userChoice;
		public int sumOfPrices;
		public int userNumberItem;
		public int orderTotal;
		public int userBudget;
		public List<Item> chains;
		public List<Item> bracelets;
		public List<Item> watches;
		public List<Item> shopCart;
		public List<int> shopCartPrices;
		public List<int> duplicatePrices;
		#endregion

		public static void Main(string[] arg)
		{
			EShopMain ems = new EShopMain();
			ems.StartScreen();
		}

		#region Inicializar variables
		public void Init()
		{
			chains = Item.AllTheChains();
			bracelets = Item.AllTheBracelets();
			watches = Item.AllTheWatches();
			shopCart = new List<Item>();
			userBudget = 10000;
			orderTotal = 0;
			shopCartPrices = new List<int>();
		}
		#endregion

		#region Pagina de Bienvenida
		public void StartScreen()
		{
			Init();
			Console.WriteLine("Welcome to My Jewelry E-Shop!");
			Console.WriteLine();
			Console.WriteLine("[S]-Start shopping!");
			Console.WriteLine("[X]-Exit");

			StartScreenOptions();
		}
		#endregion

		#region Menu Principal
		public void Menu()
		{
			Console.Clear();
			Console.WriteLine(string.Format("{0,20}", "Main Menu\n"));
			Console.WriteLine("Thank you for visiting my store!");
			Console.WriteLine("To see your budget go to the shopping cart section.\n");
			Console.Write("[C]-View the Catalog | ");
			Console.Write("[V]-View Shop Cart | ");
			Console.WriteLine("[X] Exit.");

			MenuOptions();
		}
		#endregion

		#region Catalogo de la tienda
		public void Catalog()
		{
			Console.Clear();
			Console.WriteLine(string.Format("{0,20}", "CATALOG\n"));
			Console.WriteLine("[C]-Chains");
			Console.WriteLine("[B]-Bracelets");
			Console.WriteLine("[W]-Watches\n");
			Console.WriteLine("[R]-Return to previous page");
			Console.WriteLine("[X]-Exit");
			Console.WriteLine();

			CatalogOptions();
		}
		#endregion

		#region Carrito de compra
		public void ShopCart()
		{
			Console.Clear();
			Console.WriteLine(string.Format("{0,30}", "BUDGET AND CART\n"));
			Console.WriteLine("Your budget is: " + string.Format("{0:C2}", userBudget));
			Console.WriteLine();
			Console.WriteLine(string.Format("{0,25}", "CART \n"));

			if (shopCart.Count != 0)
			{
				Console.WriteLine(string.Format("{0,30}", "Items and price\n"));
				for (int i = 0; i < shopCart.Count; i++)
				{
					Console.WriteLine(string.Format("[#{0,1:0}] {1}", i, shopCart[i].CarrView()));
				}
			}
			else
			{
				Console.WriteLine(string.Format("{0,28}", "Cart is empty!"));
			}

			sumOfPrices = shopCartPrices.Sum();
			orderTotal = sumOfPrices;

			Console.WriteLine();
			Console.WriteLine("Total: " + "$" + orderTotal);
			Console.WriteLine("=========================================");
			Console.WriteLine("             [C]-CheckOut       ");
			Console.WriteLine("=========================================");
			Console.WriteLine("[A]-Add another item | [X]-Eliminate item");
			Console.WriteLine("=========================================");
			Console.WriteLine("          [R]-Return to menu");
			Console.WriteLine("=========================================");

			CartOptions();
		}
		#endregion

		#region Productos 
		public void AllTheChains()
		{
			Console.Clear();
			Console.WriteLine(string.Format("{0,30}", "CHAINS\n"));
			Console.WriteLine(string.Format("{0,2} {1,10} {2,26} {3,8} {4}", "#", "Item", "Price", "Stock", "In ShopCart"));

			for (int i = 0; i < chains.Count; i++)
			{
				Console.WriteLine(string.Format("[C{0,1:0}] {1}", i, chains[i].ListView()));
			}
			Console.WriteLine();

			Console.Write("[A]-Add Item to cart | ");
			Console.Write("[V]-View Shop Cart | ");
			Console.WriteLine("[R]-Return to previous page");
			Console.WriteLine();
			do
			{
				userChoice = GetUserChoice("Select an option: ");
				if (userChoice == "A")
				{
					Console.WriteLine();
					AddChainsToCart();
					break;
				}
				else if (userChoice == "V")
				{
					ShopCart();
					break;
				}
				else if (userChoice == "R")
				{
					Catalog();
					break;
				}

			} while (userChoice != "A" || userChoice != "R" || userChoice != "V");
		}

		public void AllTheBracelets()
		{
			Console.Clear();
			Console.WriteLine(string.Format("{0,30}", "BRACELETS\n"));
			Console.WriteLine(string.Format("{0,2} {1,10} {2,26} {3,8} {4}", "#", "Item", "Price", "Stock", "In ShopCart"));

			for (int i = 0; i < bracelets.Count; i++)
			{
				Console.WriteLine(string.Format("[B{0,1:0}] {1}", i, bracelets[i].ListView()));
			}
			Console.WriteLine();

			Console.Write("[A]-Add Item to cart | ");
			Console.Write("[V]- View Shop Cart | ");
			Console.WriteLine("[R]-Return to previous page");
			Console.WriteLine();
			do
			{
				userChoice = GetUserChoice("Select an option: ");
				if (userChoice == "A")
				{
					Console.WriteLine();
					AddBraceletsToCart();
					break;
				}
				else if (userChoice == "V")
				{
					ShopCart();
					break;
				}
				else if (userChoice == "R")
				{
					Catalog();
					break;
				}
			} while (userChoice != "A" || userChoice != "R" || userChoice != "V");
		}

		public void AllTheWatches()
		{
			Console.Clear();
			Console.WriteLine(string.Format("{0,30}", "WATCHES\n"));
			Console.WriteLine(string.Format("{0,2} {1,10} {2,26} {3,8} {4}", "#", "Item", "Price", "Stock", "In ShopCart"));

			for (int i = 0; i < watches.Count; i++)
			{
				Console.WriteLine(string.Format("[W{0,1:0}] {1}", i, watches[i].ListView()));
			}
			Console.WriteLine();

			Console.Write("[A]-Add Item to cart | ");
			Console.Write("[V]-View Shop Cart | ");
			Console.WriteLine("[R]-Return to previous page");
			Console.WriteLine();
			do
			{
				userChoice = GetUserChoice("Select an option: ");
				if (userChoice == "A")
				{
					Console.WriteLine();
					AddWatchesToCart();
					break;
				}
				else if (userChoice == "V")
				{
					ShopCart();
					break;
				}
				else if (userChoice == "R")
				{
					Catalog();
					break;
				}
			} while (userChoice != "A" || userChoice != "R" || userChoice != "V");
		}
		#endregion

		#region Añadir los objetos al carrito
		public void AddChainsToCart()
		{
			Console.WriteLine("Adding Item to the cart");
			Console.WriteLine("Note: enter only the number in front of the C\n");
			userNumberItem = GetNumberItem("Enter the #: ");

			if (chains[0].stockQuantity != 0 && userNumberItem == 0)
			{
				shopCart.Add(chains[0]);
				shopCartPrices.Add(chains[0].price);
				chains[0].cartQuantity++;
				chains[0].stockQuantity--;
				Console.WriteLine("Item selected: " + chains[0].name);
			}
			else if (chains[1].stockQuantity != 0 && userNumberItem == 1)
			{
				shopCart.Add(chains[1]);
				shopCartPrices.Add(chains[1].price);
				chains[1].cartQuantity++;
				chains[1].stockQuantity--;
				Console.WriteLine("Item selected: " + chains[1].name);
			}
			else if (chains[2].stockQuantity != 0 && userNumberItem == 2)
			{
				shopCart.Add(chains[2]);
				shopCartPrices.Add(chains[2].price);
				chains[2].cartQuantity++;
				chains[2].stockQuantity--;
				Console.WriteLine("Item selected: " + chains[2].name);
			}
			else
			{
				Console.WriteLine("This item is out of stock or dont exists");
			}

			AddAnotherChain();

		}
		
		public void AddBraceletsToCart()
		{
			Console.WriteLine("Adding Item to the cart");
			Console.WriteLine("Note: enter only the number in front of the B\n");
			userNumberItem = GetNumberItem("Enter the #: ");

			if (bracelets[0].stockQuantity != 0 && userNumberItem == 0)
			{
				shopCart.Add(bracelets[0]);
				shopCartPrices.Add(bracelets[0].price);
				bracelets[0].cartQuantity++;
				bracelets[0].stockQuantity--;
				Console.WriteLine("Item selected: " + bracelets[0].name);
			}
			else if (bracelets[1].stockQuantity != 0 && userNumberItem == 1)
			{
				shopCart.Add(bracelets[1]);
				shopCartPrices.Add(bracelets[1].price);
				bracelets[1].cartQuantity++;
				bracelets[1].stockQuantity--;
				Console.WriteLine("Item selected: " + bracelets[1].name);
			}
			else if (bracelets[2].stockQuantity != 0 && userNumberItem == 2)
			{
				shopCart.Add(bracelets[2]);
				shopCartPrices.Add(bracelets[2].price);
				bracelets[2].cartQuantity++;
				bracelets[2].stockQuantity--;
				Console.WriteLine("Item selected: " + bracelets[2].name);
			}
			else if (bracelets[3].stockQuantity != 0 && userNumberItem == 3)
			{
				shopCart.Add(bracelets[3]);
				shopCartPrices.Add(bracelets[3].price);
				bracelets[3].cartQuantity++;
				bracelets[3].stockQuantity--;
				Console.WriteLine("Item selected: " + bracelets[3].name);
			}
			else
			{
				Console.WriteLine("This item is out of stock or dont exists");
			}

			AddAnotherBracelet();
		}

		public void AddWatchesToCart()
		{
			Console.WriteLine("Adding Item to the cart");
			Console.WriteLine("Note: enter only the number in front of the W\n");
			userNumberItem = GetNumberItem("Enter the #: ");
			if (watches[0].stockQuantity != 0 && userNumberItem == 0)
			{
				shopCart.Add(watches[0]);
				shopCartPrices.Add(watches[0].price);
				watches[0].cartQuantity++;
				watches[0].stockQuantity--;
				Console.WriteLine("Item selected: " + watches[0].name);
			}
			else if (watches[1].stockQuantity != 0 && userNumberItem == 1)
			{
				shopCart.Add(watches[1]);
				shopCartPrices.Add(watches[1].price);
				watches[1].cartQuantity++;
				watches[1].stockQuantity--;
				Console.WriteLine("Item selected: " + watches[1].name);
			}
			else if (watches[2].stockQuantity != 0 && userNumberItem == 2)
			{
				shopCart.Add(watches[2]);
				shopCartPrices.Add(watches[2].price);
				watches[2].cartQuantity++;
				watches[2].stockQuantity--;
				Console.WriteLine("Item selected: " + watches[2].name);
			}
			else if (watches[3].stockQuantity != 0 && userNumberItem == 3)
			{
				shopCart.Add(watches[3]);
				shopCartPrices.Add(watches[3].price);
				watches[3].cartQuantity++;
				watches[3].stockQuantity--;
				Console.WriteLine("Item selected: " + watches[3].name);
			}
			else
			{
				Console.WriteLine("I can't find this item");
			}

			AddAnotherWatch();

		}
		#endregion

		#region Opciones que aparecen en las paginas
		public void StartScreenOptions()
		{
			Console.WriteLine();
			do
			{
				userChoice = GetUserChoice("Select an option: ");

				if (userChoice == "S")
				{
					Menu();
					break;
				}
				else if (userChoice == "X")
				{
					ExitTheShop();
					break;
				}

				Console.WriteLine("Error: Please enter the letter in the box");
			} while (userChoice != "S" || userChoice != "X");
		}

		public void MenuOptions()
		{
			Console.WriteLine();
			do
			{
				userChoice = GetUserChoice("Select an option: ");
				if (userChoice == "C")
				{
					Catalog();
					break;
				}
				else if (userChoice == "V")
				{
					ShopCart();
					break;
				}
				else if (userChoice == "X")
				{
					ExitTheShop();
					break;
				}
				Console.WriteLine("Error: Please enter the letter in the box");
			} while (userChoice != "V" || userChoice != "X" || userChoice != "B");
		}

		public void CatalogOptions()
		{
			do
			{
				userChoice = GetUserChoice("Select an option: ");
				Console.WriteLine();
				if (userChoice == "C")
				{
					AllTheChains();
					break;
				}
				else if (userChoice == "B")
				{
					AllTheBracelets();
					break;
				}
				else if (userChoice == "W")
				{
					AllTheWatches();
					break;
				}
				else if (userChoice == "R")
				{
					Menu();
					break;
				}
				else if (userChoice == "X")
				{
					ExitTheShop();
					break;
				}
				Console.WriteLine("Error: Please enter the letter in the box");
			} while (userChoice != "C" || userChoice != "B" || userChoice != "W" || userChoice != "R" || userChoice != "X");
		}

		public void CartOptions()
		{
			Console.WriteLine();
			do
			{
				userChoice = GetUserChoice("Select an option: ");
				Console.WriteLine();
				if (userChoice == "C")
				{
					CheckOut();
					break;
				}
				else if (userChoice == "X")
				{
					RemoveItem();
					break;
				}
				else if (userChoice == "A")
				{
					Console.WriteLine("=========================================");
					Console.WriteLine("[1]-Chains | [2]-Bracelets | [3]-Watches ");
					Console.WriteLine("========================================= \n");
					userChoice = GetUserChoice("Select an option: ");
					if (userChoice == "1")
					{
						AllTheChains();
						break;
					}
					else if (userChoice == "2")
					{
						AllTheBracelets();
						break;
					}
					else if (userChoice == "3")
					{
						AllTheWatches();
						break;
					}
				}
				else if (userChoice == "R")
				{
					Menu();
					break;
				}
				Console.WriteLine("Error: Please enter the letter in the box");
			} while  (userChoice != "A" || userChoice != "C" || userChoice != "X");
		}
		#endregion

		#region Añadir mas objetos
		public void AddAnotherChain()
		{
			Console.WriteLine();
			Console.Write("[A]-Add another item | ");
			Console.Write("[V]-View Shop Cart | ");
			Console.WriteLine("[R]-Return to previous page\n");
			do
			{
				userChoice = GetUserChoice("Select an option: ");
				Console.WriteLine();
				if (userChoice == "A")
				{
					AddChainsToCart();
					break;
				}
				else if (userChoice == "V")
				{
					ShopCart();
					break;
				}
				else if (userChoice == "R")
				{
					Catalog();
					break;
				}
				Console.WriteLine("Error: Please enter the letter in the box");
			} while (userChoice != "A" || userChoice != "V" || userChoice != "R");
		}

		public void AddAnotherBracelet()
		{
			Console.WriteLine();
			Console.Write("[A]-Add another item | ");
			Console.Write("[V]-View Shop Cart | ");
			Console.WriteLine("[R]-Return to previous page\n");
			do
			{
				userChoice = GetUserChoice("Select an option: ");
				Console.WriteLine();
				if (userChoice == "A")
				{
					AddBraceletsToCart();
					break;
				}
				else if (userChoice == "V")
				{
					ShopCart();
					break;
				}
				else if (userChoice == "R")
				{
					Catalog();
					break;
				}
				Console.WriteLine("Error: Please enter the letter in the box");
			} while (userChoice != "A" || userChoice != "V" || userChoice != "R");
		}

		public void AddAnotherWatch()
		{
			Console.WriteLine();
			Console.Write("[A]-Add another item | ");
			Console.Write("[V]-View Shop Cart | ");
			Console.WriteLine("[R]-Return to previous page\n");
			do
			{
				userChoice = GetUserChoice("Select an option: ");
				Console.WriteLine();
				if (userChoice == "A")
				{
					AddWatchesToCart();
					break;
				}
				else if (userChoice == "V")
				{
					ShopCart();
					break;
				}
				else if (userChoice == "R")
				{
					Catalog();
					break;
				}
				Console.WriteLine("Error: Please enter the letter in the box");
			} while (userChoice != "A" || userChoice != "V" || userChoice != "R");
		}
		#endregion

		#region RemoveOption
		public void RemoveItem()
		{	
			if (shopCart.Count > 0)
			{
				Console.WriteLine("Removing Item!");
				userNumberItem = GetNumberItem("Enter the number: ");
				for (int i = 0; i < shopCart.Count; i++)
				{
					if (userNumberItem == shopCart.IndexOf(shopCart[i]) && userNumberItem == shopCartPrices.IndexOf(shopCartPrices[i]))
					{
						shopCart.Remove(shopCart[i]);
						shopCartPrices.Remove(shopCartPrices[i]);
					}
					else
					{
						Console.WriteLine("I cant find this item");
					}
				}
				ShopCart();
			}
			else
			{
				Console.WriteLine("No items for remove!");
				CartOptions();
			}
		}
		#endregion

		#region CheckOut
		//Opcion para pagar
		public void CheckOut()
		{
			if (userBudget >= orderTotal)
			{
				Console.WriteLine("Purchase Successful! \n");
				Console.WriteLine("=========================================");
				Console.WriteLine("[M]-Make another purchase | [E]-Exit");
				Console.WriteLine("========================================= \n");

				foreach (var item in shopCart)
				{
					item.cartQuantity = 0;
				}

				shopCart.Clear();
				shopCartPrices.Clear();
				userBudget = userBudget - orderTotal;
				orderTotal = 0;
				CheckOutOptions();
			}
			else
			{
				Console.WriteLine("Decline! \n");
				Console.WriteLine("=========================================");
				Console.WriteLine("[X]-Remove Item      |         [E]-Exit");
				Console.WriteLine("========================================= \n");
				CheckOutOptions();
			}
			//Cuando el jugador se quede sin dinero
			if (userBudget == 0)
			{
				Console.WriteLine("Decline! \n");
				Console.WriteLine("Budget is zero");
				Console.WriteLine("=========================================");
				Console.WriteLine("[X]-Remove Item      |         [E]-Exit");
				Console.WriteLine("========================================= \n");
				CheckOutOptions();
			}
		}
		//Opciones del Checkout
		public void CheckOutOptions()
		{
			do
			{
				userChoice = GetUserChoice("Select an option: ");
				if (userChoice == "M")
				{
					Catalog();
					break;
				}
				else if (userChoice == "X")
				{
					RemoveItem();
					break;
				}
				else if (userChoice == "C")
				{
					CheckOut();
					break;
				}
				else if (userChoice == "E")
				{
					ExitTheShop();
					break;
				}
			} while (userChoice != "M" || userChoice != "E" || userChoice != "C");
		}
		#endregion

		#region ExitOption Region
		public void ExitTheShop()
		{
			Console.WriteLine();
			Console.WriteLine("Leaving the store....");
			Console.WriteLine("Press <ENTER> to leave");
			Console.WriteLine();
		}
		#endregion

		#region Select Region
		//Para seleccior la opcion
		public static string GetUserChoice(string prompt)
		{
			while (true)
			{
				try
				{
					Console.Write(prompt);
					return Convert.ToString(Console.ReadLine().ToUpper());
				}
				catch
				{ }
			}
		}

		//Para seleccionar el # o la cantidad
		public static int GetNumberItem(string prompt)
		{
			while (true)
			{
				try
				{
					Console.Write(prompt);
					return Convert.ToInt32(Console.ReadLine());
				}
				catch
				{
				}
			}
		}

		#endregion
	}
}