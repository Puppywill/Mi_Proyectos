﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EShop
{
	//Stock Quantity, Cart Quantity
	public class Item
	{
		public string name;
		public int price;
		public int stockQuantity;
		public int cartQuantity;

		public Item(string n, int p, int sQ, int cQ)
		{
			name = n;
			price = p;
			stockQuantity = sQ;
			cartQuantity = cQ;
		}

		public override string ToString()
		{
			return name + price + stockQuantity + cartQuantity;
		}

		//Como se va a ver en la seccion para escoger 
		public string ListView()
		{
			return string.Format("{0,-28} {1,-10:C2} {2,-7} {3}", name, price, stockQuantity, cartQuantity);
		}
		//Como se va a ver en el carrito
		public string CartView()
		{
			return name + "      " + "$" + price;
		}
		//Como se va a ver en el carrito 2.0
		public string CarrView()
		{
			return string.Format("{0,-28} {1,-10:C2}", name, price);
		}
		//Como se va a ver el producto seleccionado
		public string ItemSelected()
		{
			return name;
		}

		public int GetPrice()
		{
			return price;
		}

		
		//Listas llenas
		public static List<Item> AllTheChains()
		{
			List<Item> chains = new List<Item>();
			chains.Add(new Item("14k gold chain            ", 100, 10, 0));
			chains.Add(new Item("14k rose gold chain       ", 130, 15, 0));
			chains.Add(new Item("14k gold chain with diamonds", 230, 10, 0));
			return chains;
		}

		public static List<Item> AllTheBracelets()
		{
			List<Item> bracelets = new List<Item>();
			bracelets.Add(new Item("14K gold diamond bracelet", 140, 15, 0));
			bracelets.Add(new Item("14k gold bracelet        ", 55, 10, 0));
			bracelets.Add(new Item("14k rose gold bracelet   ", 70, 10, 0));
			bracelets.Add(new Item("Silver bracelet          ", 30, 15, 0));
			return bracelets;
		}

		public static List<Item> AllTheWatches()
		{
			List<Item> watches = new List<Item>();
			watches.Add(new Item("Rado                    ", 2700, 15, 0));
			watches.Add(new Item("24k gold Technomarine   ", 5900, 15, 0));
			watches.Add(new Item("24k gold Rolex          ", 6000, 15, 0));
			watches.Add(new Item("G-Shock Mudmaster(black)", 840, 10, 0));
			return watches;
		}
	}
}