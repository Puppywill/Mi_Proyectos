﻿using System;

//Oscar Romero Barbosa

public class cardHolder
{
	String cardNum;
	int pinNum;
	String firstName;
	String lastName;
	double balance;

	public cardHolder(String cardnumber, int pin, String firstname, String lastname, double balance)
	{
		this.cardNum = cardnumber;
		this.pinNum = pin;
		this.firstName = firstname;	
		this.lastName = lastname;
		this.balance = balance;
	}

	#region Getters
	public String GetCardNumber()
	{
		return cardNum;
	}

	public int GetPinNumber()
	{
		return pinNum;
	}

	public String GetFirstName()
	{
		return firstName;
	}

	public String GetLastName()
	{
		return lastName;
	}

	public double GetBalance()
	{
		return balance;
	}
	#endregion

	#region Setters
	public void SetCarNumber(String newcardNum)
	{
		cardNum = newcardNum;
	}

	public void SetPinNumber(int newPin)
	{
		pinNum = newPin;	
	}

	public void SetFirstName(String newFirstname)
	{
		firstName = newFirstname;
	}

	public void SetLastName(String newLastName)
	{
		lastName = newLastName;
	}

	public void SetBalance(double newBalance)
	{
		balance = newBalance;
	}
	#endregion

	public static void Main(String[] args)
	{
		void printOptions()
		{
			Console.WriteLine("Please choose one of the following options: ");
			Console.WriteLine("[1]-Deposit \n[2]-Withdraw \n[3]-Balance \n[4]-Exit");
		}

		void Deposit(cardHolder currentUser)
		{
			Console.Write("Enter the amount to deposit $");
			double deposit = Double.Parse(Console.ReadLine());
			currentUser.SetBalance(currentUser.GetBalance() + deposit);
			Console.WriteLine("Transaction Complete!");
			Console.WriteLine("Your balance is: " + currentUser.GetBalance());
		}

		void Withdraw(cardHolder currentUser)
		{
			Console.Write("Enter the amount to withdraw $");
			double withdraw = Double.Parse(Console.ReadLine());
			//Check if user have enough money
			if (currentUser.GetBalance() < withdraw)
			{
				Console.WriteLine("Insufficient balance!");
			}
			else
			{
				currentUser.SetBalance(currentUser.GetBalance() - withdraw);
			}
		}

		void Balance(cardHolder currentUser)
		{
			Console.WriteLine("Current balance $" + currentUser.GetBalance());
		}

		List<cardHolder> cardHolders = new List<cardHolder>();
		cardHolders.Add(new cardHolder("432351638795",3902,"Oscar","Romero",105324.54));

		Console.WriteLine("Welcome to OscarATM");
		Console.Write("Please insert your card: ");
		String debitCardNum = "";
		cardHolder currentUser;

		while (true)
		{
			try
			{
				debitCardNum = Console.ReadLine();
				currentUser = cardHolders.FirstOrDefault(a => a.cardNum == debitCardNum);
				if (currentUser != null) { break; }
				else {Console.WriteLine("I don't recognize this card!");}
			}
			catch { Console.WriteLine("I don't recognize this card!"); }
		}

		Console.Write("Enter your pin: ");
		int userPin = 0;

		while (true)
		{
			try
			{
				userPin = int.Parse(Console.ReadLine());
				currentUser = cardHolders.FirstOrDefault(a => a.pinNum == userPin);
				if (currentUser != null) { break; }
				else { Console.WriteLine("Incorrect Pin!"); }
			}
			catch { Console.WriteLine("Incorrect Pin!"); }
		}

		Console.WriteLine("Welcome " + currentUser.GetFirstName());
		int option = 0;
		do
		{
			printOptions();
			try
			{
				option = int.Parse(Console.ReadLine());
			}
			catch{}

			if (option == 1)
			{
				Deposit(currentUser);
			}
			else if (option == 2)
			{
				Withdraw(currentUser);
			}
			else if (option == 3)
			{
				Balance(currentUser);
			}
			else if (option == 4)
			{
				break;
			}
			else
			{
				option = 0;
			}
		} while (option != 4);

		Console.WriteLine("Thank you for using Oscar ATM! ");
	}
}