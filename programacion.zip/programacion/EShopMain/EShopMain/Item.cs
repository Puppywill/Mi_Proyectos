﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EShop
{
    //Stock Quantity, Cart Quantity
    public class Item
    {
        public string name;
        public int price;
        public int stockQuantity;
        public int cartQuantity;
       

        public Item(string n, int p, int sQ, int cQ)
        {
            name = n;
            price = p;
            stockQuantity = sQ;
            cartQuantity = cQ;
           
        }

        public override string ToString()
        {
            return name + price + stockQuantity + cartQuantity ;
        }

        //Como se va a ver en la seccion para escoger 
        public string ListView()
        {
            return string.Format("{0,-28} {1,-10:C2} {2,-7} {3}", name, price, stockQuantity, cartQuantity);
        }


        //Como se va a ver en el carrito 2.0


        public string CarrView()
        {
            return string.Format("{0,-28} {1,-10:C2}", name, price);
        }
        //Como se va a ver el producto seleccionado
        public string ItemSelected()
        {
            return name;
        }

        public int GetPrice()
        {
            return price;
        }


        //Listas llenas
        public static List<Item> AllJoradan()
        {

            List<Item> jordan = new List<Item>();
            jordan.Add(new Item("Air Jordan 1 Bred", 450, 5, 0));
            jordan.Add(new Item("Air Jordan SpaceJam", 400, 10, 0));
            jordan.Add(new Item("Air Jordan Tokyo", 5000, 1, 0));
            jordan.Add(new Item("Air Jordan bred 11", 300, 10, 0));
            jordan.Add(new Item("Air Jordan Fake", 10, 150, 0));
   
            return jordan;
        }

        public static List<Item> AllNike()
        {
            List<Item> nike = new List<Item>();
            nike.Add(new Item("Nike lebron XX", 200, 215, 0));
            nike.Add(new Item("Nike Kobe VI Gringe", 600, 5, 0));
            nike.Add(new Item("Nike Kd IV Black Laser", 178, 100, 0));
            nike.Add(new Item("Nike PG VI HotWheel", 150, 215, 0));
            return nike;
        }

        public static List<Item> AllAdidas()
        {
            List<Item> adidas = new List<Item>();
            adidas.Add(new Item("Yeezy  350", 250, 15, 0));
            adidas.Add(new Item("Adidas Ultraboost  ", 122, 100, 0));
            adidas.Add(new Item("Adidas Forum BadBunny Blue ", 300, 15, 0));
            adidas.Add(new Item("Harden vol 2 Traffic Jam", 140, 110, 0));
            adidas.Add(new Item("Harden vol 1 ", 140, 110, 0));
            adidas.Add(new Item("Trae young 1", 140, 210, 0));
            return adidas;
        }
    }
}