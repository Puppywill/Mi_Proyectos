public class CPU {

	
	private int program_counter;
	private Proceso exec_process;

	public CPU() 
	{
		program_counter = 1;
		exec_process = null;
		System.out.println("Se creo un cpu nuevo...");

	}

	public int getProgram_counter() 
	{
		return program_counter;
	}

	public void setProgram_counter(int program_counter) 
	{
		this.program_counter = program_counter;
	}

	public Proceso getExecutingProcess() 
	{
		return this.exec_process;

	}

	public void setexec_process(Proceso p)
	{
		if (isAvailable()) {
			this.exec_process = p;
			System.out.println("Se anadio el procesador: " + p + " al cpu: " + exec_process.getPid());
		}

	}

	public boolean isAvailable() 
	{
		if (exec_process == null)
			return true;

		return false;
	}

	public void clear() 
	{
		if(excute() == true) 
		{
		this.exec_process = null;
		this.program_counter = 1;	
		}
		int pc =exec_process.getProcessControlBlock().getPc();
		int size= exec_process.getProcessControlBlock().getSize();
		
		if(pc<size) 
		{
			exec_process.incrmentPC();
		}
		
	}

	public boolean excute() 
	{
		if(exec_process==null)
			return true;
		
		if(exec_process.getProcessControlBlock().termino())
			
		return true;
		return false;
//		{
//			this.program_counter++;
//		}
//		
//	
//		
//		if(program_counter >=exec_process.getSize()) 
//		
//		{
//			return true;
//		}
//		return false;
	}
	
	
	public String toString() 
	{
		if (isAvailable() == true) 
		{
			return "CPU:" + exec_process.getPid() + " Tiene " + this.exec_process;
		}

		return "CPU:" + exec_process.getPid() + "no ningun processo........";
	}

}
