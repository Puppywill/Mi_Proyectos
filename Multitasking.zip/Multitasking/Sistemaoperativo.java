import javax.swing.DefaultListModel;

public class Sistemaoperativo  {

private	DefaultListModel<Proceso>dispatcher;
private DefaultListModel<Proceso> listadePCBs;
private	DefaultListModel<Proceso>disco ;
private DefaultListModel<Proceso>finish;
private	CPU cpu;
private RandomGeneral ran;
private int quantumTime;
private int quantumTimeWatcher;

	
	
	
	public Sistemaoperativo() 
	{
		dispatcher = new DefaultListModel<Proceso>();
		disco = new DefaultListModel<Proceso>();
		listadePCBs = new DefaultListModel<Proceso>();
		finish = new DefaultListModel<Proceso>();
		cpu = new CPU();
		ran = new RandomGeneral();
		
		quantumTime = 3;
		quantumTimeWatcher = 0;
		
	}
	
	
	private void moverdispatcher() 
	{
		if(dispatcher.getSize()==0)
		{
			if(!disco.isEmpty()) 
			{
				Proceso c = (Proceso) disco.remove(0);
				
			
				
				dispatcher.addElement(c);
			}
		}
	}
	
	public DefaultListModel<Proceso> getDispatcher()
	{
		return this.dispatcher;
	}


	public DefaultListModel<Proceso> getDisco() 
	{
		return this.disco;
	}

	
	
	public DefaultListModel <Proceso> getFinish()
	{
		return finish;
	}
	

	public DefaultListModel<Proceso> getListadePCBs() {
		return this.listadePCBs;
	}


	public void setquantumTime(int n) 
	{
		quantumTime = n;	
	}
	
	
	public int getquantumTime() 
	{
		return quantumTime;
	}

	
	
	
	public CPU getCpu() 
	{
		return this.cpu;
	}


	public RandomGeneral getRandomGeneral()
	{
		return this.ran;
	}
	
   public void movercpu() 
   {
	   if(dispatcher.getSize()!=0) 
	   {
		    if(cpu.isAvailable()) 
	   {
		   Proceso p = dispatcher.remove(0);
		   finish.addElement(p);
		   cpu.setexec_process(p);
	   }
	   
	   }
	  
	   
   }
	
private void devolverarecepcion() 
{
	disco.addElement(cpu.getExecutingProcess());
	
	cpu.clear();
}  
   
private void timesharingimplementation() 
{
    if(this.quantumTimeWatcher < this.quantumTime)	
    {
    	this.quantumTimeWatcher++;
    }
    else 
    {
    	this.quantumTimeWatcher++;
    	devolverarecepcion();
    	this.moverdispatcher();
    	this.quantumTimeWatcher=0;
    }
}
   
	public void clocktick() 
	{
		
		Proceso p = ran.getRandomProceso();
		
		if(p != null) 
		{
			disco.addElement(p);
			this.listadePCBs.addElement(p);
			
		}
		
		
		
		this.moverdispatcher();
	
		timesharingimplementation();
        
		this.movercpu();
		
		this.excute();
		
		this.excuteagain();
	}
	
	
	
	
	public void excuteagain() 
	{
		cpu.clear();
	}
	
	public void excute() 
	{
	   cpu.excute();
	   
		
		
	}
	
	public static void main(String[] args) {
		
		
	
		
	}






	
}
