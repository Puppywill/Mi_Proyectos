import java.util.Random;

public class Proceso   {

	private int size;
	private int pid;
	private int prioridad;
	private ProcessControlBlock pcb;
	
	
	
	
	
	public Proceso() 
	{
		pid= 1;
		size= getRandomsize();
		prioridad = getRandomPrioridad();
		pcb = new ProcessControlBlock();
		pcb.setSize(getRandomPrioridad());
	}
	
	
	
	public ProcessControlBlock getProcessControlBlock()
	{
		return pcb;
	}
	
	
	public Proceso(int id) 
	{
		pid=id;
		size = getRandomsize();
		prioridad = getRandomPrioridad();
		pcb = new ProcessControlBlock(id);
		pcb.setSize(getRandomPrioridad());
	}
	
	
	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	public int getPrioridad() {
		return prioridad;
	}


	public void setPrioridad(int prioridad) {
		this.prioridad = prioridad;
	}

	
	
	public int getSize() 
	{
		return size;
	}


	public void setSize(int size) 
	{
		this.size = size;
	}


	public String toString() 
	{
		return "PID :" + pid +" | "+"Size:"+ size +" Prioridad: "+ prioridad;
	}
	
	public void incrmentPC() 
	{
		pcb.setPc(pcb.getPc()+1);
	}
	
	
	
  public int getRandomsize() 
  {
	  
	 Random rand = new Random();
	 int n = rand.nextInt(10) + 1;
	 return this.size = n;
  }
	
  public int getRandomPrioridad() 
  {
	  
	 Random rand = new Random();
	 int n = rand.nextInt(10) + 1;
	 return this.prioridad = n;
  }
	
  

	
	public static void main(String[] args) {
		
		Proceso real = new Proceso();
		System.out.println(real);

	}

}
