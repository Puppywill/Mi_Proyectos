import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.border.TitledBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.border.EtchedBorder;
import java.awt.Color;
import javax.swing.JTextField;

public class GUI {

	private JFrame frame;
    private Sistemaoperativo sto;
    private  PCBGUI guipcb;
  
    

    
    
	/**
	 * Launch the application.
	 */
	public static void main(String[] args)
	{
		EventQueue.invokeLater(new Runnable()
		{
			public void run() 
			{
				try {
					GUI window = new GUI();
					window.frame.setVisible(true);
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public GUI() 
	{
		sto = new Sistemaoperativo();
		guipcb = new PCBGUI();
		initialize();
		
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() 
	{
		frame = new JFrame();
		frame.setBounds(100, 100, 904, 446);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(34, 84, 211, 184);
		frame.getContentPane().add(scrollPane);
		
		JList Dispatcher = new JList();
		Dispatcher.setBorder(new TitledBorder(null, "Dispatcher", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		Dispatcher.setModel(sto.getDispatcher());
		scrollPane.setViewportView(Dispatcher);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(343, 84, 232, 173);
		frame.getContentPane().add(scrollPane_1);
		
		JList Disk = new JList();
		Disk.setBorder(new TitledBorder(null, "Disk", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		Disk.setModel(sto.getDisco());
		scrollPane_1.setRowHeaderView(Disk);
		
		JButton btnNewButton = new JButton("Click_tick");
		
		btnNewButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e)
			{
				
				sto.clocktick();
				
				
			}
			
		});
		btnNewButton.setBounds(249, 322, 159, 51);
		frame.getContentPane().add(btnNewButton);
		
		JList pnl_finish = new JList();
		pnl_finish.setModel(sto.getFinish());
		pnl_finish.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Finish", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		pnl_finish.setBounds(636, 70, 209, 182);
		frame.getContentPane().add(pnl_finish);
		
		JButton btnControlblocktick = new JButton("PCB_click");
		btnControlblocktick.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				guipcb.setVisible(true);
			}
		});
		btnControlblocktick.setBounds(518, 322, 159, 51);
		frame.getContentPane().add(btnControlblocktick);
		
		guipcb.setlista(sto.getListadePCBs());
		
		
	}
}
