import javax.swing.DefaultListModel;

public class Sistemaoperativo  {

private	DefaultListModel<Proceso>dispatcher;
private DefaultListModel  listadePCBs;
private	DefaultListModel<Proceso>disco ;
private DefaultListModel<Proceso>finish;
private	CPU cpu;
private RandomGeneral ran;
private int quantumTime;
private int quantumTimeWatcher;

	
	
	
	public Sistemaoperativo() 
	{
		dispatcher = new DefaultListModel<Proceso>();
		disco = new DefaultListModel<Proceso>();
		listadePCBs = new DefaultListModel();
		finish = new DefaultListModel<Proceso>();
		cpu = new CPU();
		ran = new RandomGeneral();
		
		quantumTime = 3;
		quantumTimeWatcher = 0;
		
	}
	
	
	private void moverdispatcher() 
	{
		if(dispatcher.getSize()==0)
		{
			if(!disco.isEmpty()) 
			{
				Proceso c = (Proceso) disco.remove(0);
				
			
				
				dispatcher.addElement(c);
			}
		}
	}
	
	public DefaultListModel<Proceso> getDispatcher()
	{
		return this.dispatcher;
	}


	public DefaultListModel<Proceso> getDisco() 
	{
		return this.disco;
	}

	
	
	public DefaultListModel <Proceso> getFinish()
	{
		return finish;
	}
	

	public DefaultListModel getListadePCBs() {
		return this.listadePCBs;
	}


	public void setquantumTime(int n) 
	{
		quantumTime = n;	
	}
	
	
	public int getquantumTime() 
	{
		return quantumTime;
	}

	
	
	
	public CPU getCpu() 
	{
		return this.cpu;
	}


	public RandomGeneral getRandomGeneral()
	{
		return this.ran;
	}
	
   public void movercpu() 
   {
	   if(dispatcher.getSize()!=0) 
	   {
		    if(cpu.isAvailable()) 
	   {
		   Proceso p = dispatcher.remove(0);
		   cpu.setexec_process(p);
	   }
	   
	   }
	  
	   
   }
	
private void devolverarecepcion() 
{
	disco.addElement(cpu.getExecutingProcess());
	
	cpu.clear();
}  
   
private void timesharingimplementation() 
{
    if(this.quantumTimeWatcher < this.quantumTime)	
    {
    	this.quantumTimeWatcher++;
    }
    else 
    {
    	this.devolverarecepcion();
    	this.movercpu();
    	this.quantumTimeWatcher=0;
    }
}
   
	public void clocktick() 
	{
		
		Proceso p = ran.getRandomProceso();
		
		if(p != null) 
		{
			disco.addElement(p);
			this.listadePCBs.addElement(p.getProcessControlBlock());
			
			
		}
		
		this.moverdispatcher();
	
		this.movercpu();
        
		timesharingimplementation();
		
		this.excute();
		
		this.terminoEjecucion();
	}
	
	
	
	
	public void terminoEjecucion() 
	{
		if(cpu.terminoEjecucion()) {
			finish.addElement(cpu.getExecutingProcess());
			cpu.clear();
		}
	}
	
	public void excute() 
	{
	   cpu.excute();
	}
	
	public static void main(String[] args) {
		
		
	
		
	}






	
}
