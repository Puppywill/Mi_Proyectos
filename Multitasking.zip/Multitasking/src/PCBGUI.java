import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JScrollPane;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.border.TitledBorder;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class PCBGUI extends JFrame {

	private JPanel contentPane;
    private JList list;
    private Sistemaoperativo so;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PCBGUI frame = new PCBGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public PCBGUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 853, 408);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 43, 817, 216);
		contentPane.add(scrollPane);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane.setViewportView(scrollPane_1);
		
		 list = new JList();
		list.setBorder(new TitledBorder(null, "ControlBlock", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		scrollPane_1.setViewportView(list);
				
		JButton btnNewButton = new JButton("Close");
		btnNewButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e)
			{
				esconderpantalla();
			}
		});
		btnNewButton.setBounds(376, 309, 89, 23);
		contentPane.add(btnNewButton);
	}
	
public void esconderpantalla() 
{

	this.setVisible(false);
	
	
}

public void setlista(DefaultListModel<Proceso> modelo ) 
{
    	list.setModel(modelo);
}

}

